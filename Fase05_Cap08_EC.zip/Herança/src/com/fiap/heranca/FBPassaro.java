package com.fiap.heranca;

public class FBPassaro extends FBAnimal {
	
	private String pia;
		
	public String getPia() {
		return pia;
	}
		
	public void setLatido(String pia) {
		this.pia = pia;
	}

}



