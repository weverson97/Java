package com.fiap.heranca;

public class FBAnimal {
	
	private String locomove;
	private String alimenta;
	
	public String getLocomove() {
		return locomove;
	}

	public void setLocomove(String locomove) {
		this.locomove = locomove;
	}
	
	public String getAlimenta() {
		return alimenta;
	}
	
	public void setalimenta(String alimenta) {
		this.alimenta = alimenta;
	}

}
