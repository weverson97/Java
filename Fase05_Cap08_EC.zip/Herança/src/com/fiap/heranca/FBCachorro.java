package com.fiap.heranca;

public class FBCachorro extends FBAnimal{
	
	private String latido;
	
	
	public String getLatido() {
		return latido;
	}
	
	public void setLatido(String latido) {
		this.latido = latido;
	}

}
