package com.fiap.heranca;

public class Teste {
	public static void main(String[] args) {
		
		
		// Criei uma FB com o nome gato apartir da FB animal
		FBAnimal gato = new FBAnimal();
		gato.setalimenta("Todo animal se alimenta");
		gato.setLocomove("Todo animal se locomove");
		
		// Criei uma FB com o nome kalvin apartir da FB cachorro. 
		// Herdará os atributos (alimenta e locomove) da classe
		// pai (FBAnimal) e acrescentará o atributo (latido)
		// da classe filho (FBCachorro)
		FBCachorro kalvin = new FBCachorro();
		kalvin.setalimenta("Cachorro come ração de cachorro");
		kalvin.setLocomove("Cachorro tem 4 patas");
		kalvin.setLatido("Cachorro faz Au Au");
		
		FBAnimal yorkshare = new FBCachorro();
		yorkshare.setalimenta(" YorkShare come ração de cachorro");
		yorkshare.setLocomove(" YorkShare usa 4 patas");
		
	}

}
