import java.util.Scanner;

public class HelloJava {
	public static void main(String[] args) {

		int idade = 0;
		
		Scanner sc = new Scanner (System.in);
		
		System.out.println( "digite o nome: " );
		
		// the syntax (Next) only receive from user words without space 
		 String name = sc.next(); //
		
		// the syntax (nextLine) only receive from user words with space 
		// String name = sc.nextLine(); //
		
		
		
		System.out.println( "digite a idade: " );
		idade = sc.nextInt();
		
		if (idade <0) System.out.println( "Idade inválida" );
		
		
		if (idade >= 18 && idade < 70) {
			
			System.out.println( "Maior idade" );
			
		} else if (idade > 70) {
			System.out.println( "Centenaria" );
			
		}
	}
}