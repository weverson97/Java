
public class FunctionBlockCliente {
	byte age;
	String name;

}
