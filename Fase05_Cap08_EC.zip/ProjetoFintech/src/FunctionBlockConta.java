
public class FunctionBlockConta {
	double balance;
	int number;
	
	FunctionBlockCliente client = new FunctionBlockCliente();

}
