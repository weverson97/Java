
public class TesteConta {
	public static void main(String[] args) {
		
	
		FunctionBlockConta ContaCorrente = new FunctionBlockConta ();
		FunctionBlockConta ContaPoupanca = new FunctionBlockConta ();
		FunctionBlockConta ContaInvestimento = new FunctionBlockConta ();
		
		ContaCorrente.number = 11;
		ContaCorrente.balance = 25.50;
		ContaCorrente.client.name = "Weverson Silva";
		ContaCorrente.client.age = 25;
		
		ContaPoupanca.number = 22;
		ContaPoupanca.balance = 20000.00;
		ContaPoupanca.client.name = "Marilene Lins";
		ContaPoupanca.client.age = 58;	
		
		
		ContaInvestimento.number = 33;
		ContaInvestimento.balance = -50000.00;
		ContaInvestimento.client.name = "Wallace Silva";
		ContaInvestimento.client.age = 27;
		
		System.out.println(ContaCorrente.number);
		System.out.println(ContaCorrente.balance);
		System.out.println(ContaCorrente.client); // create account from client  
		System.out.println(ContaCorrente.client.name); // inform name from account of client 
		System.out.println(ContaCorrente.client.age); // inform age from account of client 
		
		
	}

}
