
public class FunctionBlockCliente {
	byte idade;
	String nome;

}
