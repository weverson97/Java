
public class FunctionBlockConta {
	double saldo;
	int numero;
	
	FunctionBlockCliente cliente = new FunctionBlockCliente();

}
