
public class TesteConta {
	public static void main(String[] args) {
		
		
		FunctionBlockConta ContaCorrente = new FunctionBlockConta ();
		FunctionBlockConta ContaPoupanca = new FunctionBlockConta ();
		FunctionBlockConta ContaInvestimento = new FunctionBlockConta ();
		
		ContaCorrente.numero = 11;
		ContaCorrente.saldo = 25.50;
		ContaCorrente.cliente.nome = "Weverson Silva";
		ContaCorrente.cliente.idade = 25;
		
		ContaPoupanca.numero = 22;
		ContaPoupanca.saldo = 20000.00;
		ContaPoupanca.cliente.nome = "Marilene Lins";
		ContaPoupanca.cliente.idade = 58;	
		
		
		ContaInvestimento.numero = 33;
		ContaInvestimento.saldo = -50000.00;
		ContaInvestimento.cliente.nome = "Wallace Silva";
		ContaInvestimento.cliente.idade = 27;
		
		System.out.println(ContaCorrente.numero);
		System.out.println(ContaCorrente.saldo);
		System.out.println(ContaCorrente.cliente); // create account from client  
		System.out.println(ContaCorrente.cliente.nome); // inform name from account of client 
		System.out.println(ContaCorrente.cliente.idade); // inform name from account of client 
		
		
	}
	
}
