package br.com.fiap.banco;

public class TesteJava {
	public static void main(String[] args) {
		
		//Account Current
		FBConta contaCorrente = new FBConta();
		
		contaCorrente.agencia = 123;
		contaCorrente.numero = 321;
		contaCorrente.saldo = 50.0;
		
		contaCorrente.depositar(1000);
		System.out.println(contaCorrente.verificarSaldo());
		
		
		//Account Poupança
		FBConta contaPoupanca = new FBConta(234, 342, 5000.0);
		System.out.println(contaPoupanca.verificarSaldo());
		contaPoupanca.retirar(50);
		System.out.println(contaPoupanca.verificarSaldo());
		
	}

}
