package br.com.fiap.banco;

public class FBConta {

	int agencia;
	int numero;
	double saldo;

	public FBConta() {

	}

	public FBConta(int agencia, int numero, double saldo) {
		this.agencia = agencia;
		this.numero = numero;
		this.saldo = saldo;
	}

	public void depositar(double valor) {
		this.saldo += valor;
	}

	public void retirar(double valor) {
		this.saldo -= valor; 
	}


	// Seleciona as linhas, Control + Shift + / comenta a linha
	  public double verificarSaldo() { 
		  return this.saldo;
		// Seleciona as linhas, Control + Shift + \ retira os comentarios	  
	  }
	 
  
}
 
